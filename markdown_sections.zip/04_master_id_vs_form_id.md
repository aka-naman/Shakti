# 04 Master Id Vs Form Id

1. Is the Master ID same as the Form ID?
      No. The Master ID (e.g., master_tbrl_001) belongs to the Word Template in the Noting app. The Form ID (e.g., 23)
  belongs to the database table in Agra-sandhani. We need a "map" to link them.
   2. What if a table is deleted/recreated?
      Yes, the database will give it a new ID. You would need to update that ID in the Noting app so it knows where to
  look now.
   3. Locations to change:
       * masters.json: To store the link.
       * app.py: To read the link and pass it to the form.
       * pis_bridge.js: To use that specific ID when searching.
