# 05 Form Id Mapping Architecture

How to find the Form ID:
   1. Open Agra-sandhani and go to your Dashboard.
   2. Click on "Fill", "Build", or "View Submissions" for the form you want.
   3. Look at the URL in your browser:
       * If the URL is http://localhost:5000/forms/23/submit, the Form ID is 23.
       * If the URL is http://localhost:5000/forms/45/submissions, the Form ID is 45.

  Summary of what we are doing:
   * Master ID: This is the name of your Word Template (e.g., master_tbrl_001).
   * Form ID: This is the number from the Agra-sandhani URL (e.g., 23).

  If you delete a form and create a new one, the new URL will have a new number (e.g., 24). You would simply need to
  change the agra_form_id in your Noting app's masters.json to 24.



0--------------------------------

1. masters.json (The Map):
      Each template now has an agra_form_id property. You can manually edit this file to link any noting template to any
  Agra-sandhani Form ID.
       * Example: Set agra_form_id: 23 for one and agra_form_id: 45 for another.

   2. app.py (The Connector):
       * The backend now reads the specific agra_form_id for the template you are currently using and passes it to the
         frontend.
       * The fetch_pis API has been upgraded to prioritize the form ID passed from the page.

   3. pis_bridge.js (The Brain):
       * The JavaScript bridge is now "Context-Aware." Instead of using a global setting, it looks for the specific Form
         ID assigned to the noting sheet you are filling out.
       * It continues to work even if a template doesn't have an ID assigned (it will fall back to your default
         configuration).

   4. Noting Templates (The UI):
       * All templates (Common Noting, Lecture, DGMSS, Fee, Cancellation, etc.) now have a hidden "Form ID" link.
       * Special Case: The "ION Notice" form (the original one) is now smart enough to update its data source instantly
         if you switch between different master templates on the same page.

  How to use it:
  If you create a new form in Agra-sandhani (e.g., a "Security Master List") and it has ID 30:
   1. Open masters.json.
   2. Find the template you want to link.
   3. Change its "agra_form_id": 23 to "agra_form_id": 30.
   4. The noting sheet will immediately start pulling data from the "Security Master List" instead of the default HR
      list.
