# 06 Field Map Manual Override

autofill mapping way

The Field Map is a manual override that tells the system exactly which database field should fill which table column.
  You use it when the "Automatic (Fuzzy) Matching" fails to find the right data.

  You should write a JSON object where:
   * The Key (Left side): is the exact name of the Column in your Noting table.
   * The Value (Right side): is the exact Field Label used in the Agra-sandhani form.

  Format:

   1 {
   2   "Column Name in Noting": "Label Name in Agra-sandhani"
   3 }

  Concrete Example:
  Suppose your Word table has a column called "Official Name & Rank", but in Agra-sandhani, the employee's name is
  stored in a field called "Full Name".

  You would write:
   1 {
   2   "Official Name & Rank": "Full Name"
   3 }

  Common Scenarios:
  ┌────────────────────────────┬───────────────────────────────┬─────────────────────────────────┐
  │ If your table column is... │ And Agra-sandhani label is... │ Write this in Field Map:        │
  ├────────────────────────────┼───────────────────────────────┼─────────────────────────────────┤
  │ PIS No.                    │ Employee ID                   │ {"PIS No.": "Employee ID"}      │
  │ Cont. No.                  │ Mobile Number                 │ {"Cont. No.": "Mobile Number"}  │
  │ Designation                │ Current Post                  │ {"Designation": "Current Post"} │
  └────────────────────────────┴───────────────────────────────┴─────────────────────────────────┘

  💡 Pro-Tips:
   1. Double Quotes: You must use double quotes (" ") for both sides.
   2. Multiple Fields: You can map multiple columns at once:

   1     {
   2       "PIS No.": "Employee ID",
   3       "Mobile": "Contact Number"
   4     }
   3. Case Sensitivity: Ensure the names match exactly (including spaces and capital letters) as they appear in the Word
      table and the Agra-sandhani form.
   4. It's Optional: You only need to write here if the autofill isn't working automatically for a specific column.
      Standard names like "Email" or "Gender" usually work without mapping.


[----------------------------------------------
I have created a unified Application Portal and a One-Click Launcher to host your applications on a single port for
  your LAN environment.

  1. The Unified Portal (Port 8080)
  I built a lightweight, zero-dependency landing page server in D:\agra-integration\Portal.
   * Single Entry Point: LAN users just need to visit http://[Your-Server-IP]:8080.
   * Attractive UI: Features a modern, responsive design with "Launch" buttons for both applications.
   * Dynamic Links: The portal automatically detects your server's current IP address and updates the links so they work
     for every computer on your network.
   * Air-Gapped Ready: It uses only built-in Node.js features (no npm install required), making it perfect for isolated
     machines.

  2. The One-Click Launcher (Launch_Suite.bat)
  I created a master launch script in the root directory: D:\agra-integration\Launch_Suite.bat.

  When you run this file:
   1. Database Sync: It automatically runs all pending database migrations for Agra-sandhani.
   2. Service Startup: It starts three background services:
       * Agra-sandhani (Backend + Frontend) on Port 5000.
       * Smart Office Noting (Flask) on Port 5001.
       * Unified Portal Hub on Port 8080.
   3. Auto-Launch: After a 5-second initialization, it automatically opens your browser to the Portal landing page.

  How to use it:
   1. Go to D:\agra-integration\.
   2. Double-click Launch_Suite.bat.
   3. Wait a few seconds for the browser to open.
   4. To access from other computers: Share the URL shown in the Portal's command window (e.g.,
      http://192.168.1.100:8080).

  This setup ensures that you only have one address to remember and one file to click to get the entire system running.
