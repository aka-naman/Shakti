# 03 Noting Autofill Workflow

reason for autofilling of noting

 1. How the Autofill Works
  The process is handled by a JavaScript component called the PIS Bridge (static/js/pis_bridge.js) and a proxy in the
  backend (app.py).

   * Detection: When you create a table in a noting form, the system automatically checks the column headers. If a
     column contains keywords like "PIS", "Personnel", or "Emp ID", the bridge attaches an "Autocomplete" and "Fetch"
     listener to those cells.
   * Search (Autocomplete): As you start typing a PIS number, the bridge sends a request to the backend. It searches the
     Agra-sandhani database for matching records and shows a dropdown with the PIS and Name.
   * Fetching & Mapping: Once a PIS is selected:
       1. The system fetches the full record (JSON data) associated with that PIS from the database.
       2. It uses Fuzzy Matching to map database fields to your table columns. For example, if your table has a column
          named "Cont. No." and the database has "Mobile Number," the bridge is smart enough to link them.
       3. It automatically fills the "Name", "Designation", "Gender", "DOB", "Email", and "Contact" fields in that
          specific row.

  2. Where the Data is Imported From
  The data is imported from the Agra-sandhani application (the Multi-User Dynamic Form Builder).

   * Source Database: It pulls from the submissions table in the PostgreSQL database used by Agra-sandhani.
   * Master Form: By default, it looks into a specific form designated as the "Master Record" (configured in config.json
     as master_form_id: 23). This is typically an "Employee Profile" or "Master Data" form where all personnel details
     are stored.
   * Integration Point: The noting app communicates with Agra-sandhani via an internal API endpoint:
     http://localhost:5000/api/service/lookup.

  Summary of the Flow:
   1. User types PIS in smart-office-noting (Port 5001).
   2. Python Backend proxies the request to Agra-sandhani (Port 5000).
   3. Agra-sandhani queries the PostgreSQL DB for the latest submission matching that PIS.
   4. Agra-sandhani sends back the JSON data + a "suggested mapping."
   5. PIS Bridge on the frontend populates your table rows instantly.

  You can find the specific integration settings (like the API URL and Master Form ID) in the config.json file located
  in the smart-office-noting root directory.
